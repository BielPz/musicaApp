package com.example.ransongz

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.IOException
import kotlin.random.Random

class MusicaAtual : AppCompatActivity() {

    lateinit var txtNomeMusica: TextView
    lateinit var txtNomeAutor: TextView
    lateinit var imgCapaMusica: ImageView

    lateinit var barra_musica: SeekBar
    lateinit var txtTempo: TextView

    lateinit var btnVoltarTela: ImageButton
    lateinit var btnPauseMusic: ImageButton
    lateinit var btnAudio: ImageButton
    lateinit var btnLooping: ImageButton

    private lateinit var runnable: Runnable
    private var handler = Handler()

    // Variavel de um biblioteca que cria um Tocador de midia
    // Enquanto ela não estiver sendo usado o valor dela é NULL
    // private var mediaPlayer: MediaPlayer? = null
    var mediaPlayer = MediaPlayer()

    // matriz cubica, guarda nome autor e link para musica
    val musicas = arrayOf(
        // rock
        arrayOf(
            arrayOf("Bohemian Rhapsody", "Queen", "bohemianrhapsody", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Rock/bohemianrhapsody.m4a"),
            arrayOf("Welcome To The Jungle", "Guns N' Roses", "welcometothejungle","https://raw.githubusercontent.com/BielPz/musicaApp/main/Rock/welcometothejungle.m4a"),
            arrayOf("Smells Like Teen Spirit", "Nirvana", "smellsliketeenspirit", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Rock/smellsliketeenspirit.m4a"),
            arrayOf("Californication", "Red Hot Chili Peppers", "californication", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Rock/californication.m4a"),
            arrayOf("Hotel California", "Eagles", "hotelcalifornia", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Rock/hotelcalifornia.m4a")
        ),

        // sertanejo
        arrayOf(
            arrayOf("Borboletas", "Victor e Leo", "borboletas", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Sertanejo/borboletas.m4a"),
            arrayOf("No dia em que eu saí de casa", "Zezé Di Camargo e Luciano", "nodiaemqueeusaidecasa", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Sertanejo/nodiaemqueeusaidecasa.m4a"),
            arrayOf("O menino da porteira", "Sérgio Reis", "omeninodaporteira", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Sertanejo/omeninodaporteira.m4a"),
            arrayOf("Boate azul", "Joaquim e Manuel", "boateazul", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Sertanejo/boateazul.m4a"),
            arrayOf("Evidências", "Chitãozinho e Xororó", "evidencias", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Sertanejo/evidencias.m4a")
        ),

        // eletronica
        arrayOf(
            arrayOf("Hear me now", "Alok, Bruno Martini ft. Zeeba", "hearmenow", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Eletronica/hearmenow.m4a"),
            arrayOf("Happier", "Marshmello ft. Bastille", "happier", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Eletronica/happier.m4a"),
            arrayOf("Alone", "Marshmello", "alone", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Eletronica/alone.m4a"),
            arrayOf("Fly", "Marshmello ft. Leah Culver", "fly", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Eletronica/fly.m4a"),
            arrayOf("Piece of your heart", "Alok Remix, Medusa ft. Goodboys", "pieceofyourheart", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Eletronica/pieceofyourheart.m4a")
        ),

        // pop
        arrayOf(
            arrayOf("Cruel Summer", "Taylor Swift", "cruelsummer", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Pop/cruelsummer.m4a"),
            arrayOf("Never say never", "Justin Bieber ft. Jaden Smith", "neversaynever", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Pop/neversaynever.m4a"),
            arrayOf("Die with a smile", "Lady Gaga ft. Bruno Mars", "diewithasmile", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Pop/diewithasmile.m4a"),
            arrayOf("Enemy", "Imagine Dragons ft. J.I.D", "enemyimagine", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Pop/enemyimagine.m4a"),
            arrayOf("Crazy in love", "Beyoncé ft. Jay Z", "crazyinlove", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Pop/crazyinlove.m4a")
        ),

        // kpop
        arrayOf(
            arrayOf("Dynamite", "BTS", "dynamite", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Kpop/dynamite.m4a"),
            arrayOf("Money", "Lisa", "money", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Kpop/money.m4a"),
            arrayOf("Maniac", "Stray kids", "maniac", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Kpop/maniac.m4a"),
            arrayOf("Loveable", "사랑스러워) SINB (신비) - GFriend (여자친구)", "loveable", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Kpop/loveable.m4a"),
            arrayOf("Breaking Down", "Ailee", "breakingdown", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Kpop/breakingdown.m4a")
        ),

        // classica
        arrayOf(
            arrayOf("Gymnopédie No.1", "Erik Satie", "eriksatie", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Classica/gymnopedie_no1.m4a"),
            arrayOf("Clair de Lune", "Claude Debussy", "lune", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Classica/clair_de_lune.m4a"),
            arrayOf("Waltz No. 2", "Dmitri Shostakovich", "dmitri", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Classica/waltz_no_2.m4a"),
            arrayOf("Swan Lake", "Tchaikovsky", "swanlake", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Classica/swan_lake_theme.m4a"),
            arrayOf("Pas de Deux ('The Nutcracker')", "P. Tchaikovsky", "pasdedeux", "https://raw.githubusercontent.com/BielPz/musicaApp/main/Classica/pas_de_deux.m4a")
        ),
    )


    // variavel que guarda a musica atual
    var musica_atual: Array<String>? = null

    // variavel que guarda a ultima musica sorteada
    var ultima_musica: Array<String>? = null

    var genero_escolhido: Int? = null

    // variavel de controle da função silenciar
    var silenciar = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_musica_atual)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        txtNomeMusica = findViewById(R.id.txtNomeMusica)
        txtNomeAutor = findViewById(R.id.txtNomeAutor)
        imgCapaMusica = findViewById(R.id.capamusica)

        barra_musica = findViewById(R.id.barra_musica)
        txtTempo = findViewById(R.id.txtTempo)

        btnVoltarTela = findViewById(R.id.btnVoltarTela)
        btnPauseMusic = findViewById(R.id.btnPauseMusic)
        btnAudio = findViewById(R.id.btnAudio)
        btnLooping = findViewById(R.id.btnLooping)

        sortear_musica()


        btnVoltarTela.setOnClickListener()
        {
            if (mediaPlayer.isPlaying)
            {
                mediaPlayer.stop()
            }
            mediaPlayer.release()
            handler.removeCallbacks(runnable)
            finish()
        }

        // ************************************************************
        // Função escrita pelo canal Coder para atualizar o seekBar
        // ************************************************************

        // Configurando a mídia para ser reproduzida a qualquer momento alterando a posição da seekBar
        barra_musica.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                // Se a posição do seekBar mudou, altera o tempo da mídia
                if(fromUser)
                {
                    mediaPlayer.seekTo(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }

        })
    }


    fun sortear_musica() {
        // Recolhe dados de outra tela, caso seja nulo ele sorteara de 0 a 5
        genero_escolhido = intent.extras?.getInt("genero escolhido")

        btnPauseMusic.setImageResource(R.drawable.btnpause)

        if (genero_escolhido == (-1))
        {
            genero_escolhido = Random.nextInt((musicas.size))
        }

        if (ultima_musica == null)
        {
            musica_atual = musicas[genero_escolhido!!][Random.nextInt(musicas[genero_escolhido!!].size)]
            ultima_musica = musica_atual
        }
        else
        {
            do
            {
                musica_atual = musicas[genero_escolhido!!][Random.nextInt(musicas[genero_escolhido!!].size)]
            }
            while (musica_atual == ultima_musica)

            ultima_musica = musica_atual
        }

        txtNomeMusica.setText(musica_atual!![0])
        txtNomeAutor.setText(musica_atual!![1])
        imgCapaMusica.setImageResource(resources.getIdentifier(musica_atual!![2], "drawable", packageName))

        try
        {
            mediaPlayer.release()
            mediaPlayer = MediaPlayer().apply {
                // Função retirada da documentação da biblioteca AudioAttributes
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(musica_atual!![3])
                prepare()
                start()
            }

            // ************************************************************
            // Função escrita pelo canal Coder para atualizar o seekBar
            // ************************************************************

            // Inicializando a seekBar com 0 e com duração igual a da musica
            barra_musica.progress = 0
            barra_musica.max = mediaPlayer.duration

            // atualizando a seekBar com o tempo
            runnable = Runnable {
                barra_musica.progress = mediaPlayer.currentPosition

                val tempoCorrente = mediaPlayer.currentPosition / 1000
                val duracaoMusica = mediaPlayer.duration / 1000

                val minutosCorrente = tempoCorrente / 60
                val segundosCorrente = tempoCorrente % 60

                val minutosMusica = duracaoMusica / 60
                val segundosMusica = duracaoMusica % 60

                txtTempo.text = String.format("%02d:%02d / %02d:%02d", minutosCorrente, segundosCorrente, minutosMusica, segundosMusica)

                handler.postDelayed(runnable,1000)
            }

            // Agora defina o horário em que a duração da mídia terminou
            handler.postDelayed(runnable,1000)
            mediaPlayer.setOnCompletionListener {
                // Quando a musica terminar ela mostra isso
                mediaPlayer.pause()
                btnPauseMusic.setImageResource(R.drawable.sortearmusica)
            }
        }
        catch (e: IOException)
        {
            Toast.makeText(this, "Erro ao preparar/tocar a música " + e, Toast.LENGTH_SHORT).show()
        }
    }


    fun botao_sortear(view: View)
    {
        sortear_musica()
    }

    // ************************************************************
    // Função escrita pelo canal Stack Mobile para pausar a musica
    // ************************************************************
    fun botao_pausar(view: View)
    {
        if(mediaPlayer.isPlaying)
        {
            mediaPlayer.pause()
            btnPauseMusic.setImageResource(R.drawable.sortearmusica)
        }
        else
        {
            mediaPlayer.start()
            btnPauseMusic.setImageResource(R.drawable.btnpause)
        }
    }

    // Função para voltar o musica para o inico
    fun botao_MusicaReset(view: View)
    {
        mediaPlayer.seekTo(0)
    }

    fun botao_Silenciar(view: View)
    {
        silenciar *= (-1)
        if(silenciar == (-1))
        {
            mediaPlayer.setVolume(0.0f,0.0f)
            btnAudio.setImageResource(R.drawable.btnaudiooff)
        }
        else
        {
            mediaPlayer.setVolume(1.0f,1.0f)
            btnAudio.setImageResource(R.drawable.btnaudioon)
        }
    }

    fun botao_Looping(view: View)
    {
        if(mediaPlayer.isLooping)
        {
            mediaPlayer.isLooping = false
            btnLooping.setImageResource(R.drawable.btnloopoff)
        }
        else
        {
            mediaPlayer.isLooping = true
            btnLooping.setImageResource(R.drawable.btnloopon)
        }
    }
}



