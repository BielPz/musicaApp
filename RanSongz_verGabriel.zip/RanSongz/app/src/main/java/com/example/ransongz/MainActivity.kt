package com.example.ransongz

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    /* -------------------------------------
       Funções de Selecão de Gênero Musical
       ------------------------------------- */
    fun sel_rock(view: View)
    {
        sortear(0)
    }

    fun sel_sertanejo(view: View)
    {
        sortear(1)
    }

    fun sel_eletronica(view: View)
    {
        sortear(2)
    }

    fun sel_pop(view: View)
    {
        sortear(3)
    }

    fun sel_kpop(view: View)
    {
        sortear(4)
    }

    fun sel_classica(view: View)
    {
        sortear(5)
    }

    fun sel_all(view: View)
    {
        sortear(-1)
    }

    // Função para selecionar um gênero musical que sera sorteado em outra tela
    private fun sortear(genero_escolhido: Int?)
    {
        val intent = Intent(applicationContext, MusicaAtual::class.java)

        intent.putExtra("genero escolhido",genero_escolhido)

        startActivity(intent)
    }
}